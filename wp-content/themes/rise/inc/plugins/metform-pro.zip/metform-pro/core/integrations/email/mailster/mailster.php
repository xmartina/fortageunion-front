<?php

namespace MetForm_Pro\Core\Integrations\Email\Mailster;

defined('ABSPATH') || exit;

class Mailster
{
    public function action($form_id, $form_data , $settings)
    {
        
    }

}